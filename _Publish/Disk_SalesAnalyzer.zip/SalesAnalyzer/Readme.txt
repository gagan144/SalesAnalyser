SPA - Sales Process Analyzer
For windows only

The software requires JDK 1.6.0 or higher. You may install JDK
by running 'jdk-6-windows.exe' from current directory.
